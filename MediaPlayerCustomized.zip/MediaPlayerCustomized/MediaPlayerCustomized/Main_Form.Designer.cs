﻿namespace MediaPlayerCustomized
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.BtnOpenFiles = new System.Windows.Forms.Button();
            this.ListFiles = new System.Windows.Forms.ListBox();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.BtnPlay = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnPause = new System.Windows.Forms.Button();
            this.CmbLenguage = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnOpenFiles
            // 
            resources.ApplyResources(this.BtnOpenFiles, "BtnOpenFiles");
            this.BtnOpenFiles.Name = "BtnOpenFiles";
            this.BtnOpenFiles.UseVisualStyleBackColor = true;
            this.BtnOpenFiles.Click += new System.EventHandler(this.BtnOpenFiles_Click);
            // 
            // ListFiles
            // 
            resources.ApplyResources(this.ListFiles, "ListFiles");
            this.ListFiles.FormattingEnabled = true;
            this.ListFiles.Name = "ListFiles";
            this.ListFiles.SelectedIndexChanged += new System.EventHandler(this.ListFiles_SelectedIndexChanged);
            // 
            // axWindowsMediaPlayer1
            // 
            resources.ApplyResources(this.axWindowsMediaPlayer1, "axWindowsMediaPlayer1");
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            // 
            // BtnPlay
            // 
            resources.ApplyResources(this.BtnPlay, "BtnPlay");
            this.BtnPlay.Name = "BtnPlay";
            this.BtnPlay.UseVisualStyleBackColor = true;
            this.BtnPlay.Click += new System.EventHandler(this.BtnPlay_Click);
            // 
            // BtnStop
            // 
            resources.ApplyResources(this.BtnStop, "BtnStop");
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnPause
            // 
            resources.ApplyResources(this.BtnPause, "BtnPause");
            this.BtnPause.Name = "BtnPause";
            this.BtnPause.UseVisualStyleBackColor = true;
            this.BtnPause.Click += new System.EventHandler(this.BtnPause_Click);
            // 
            // CmbLenguage
            // 
            resources.ApplyResources(this.CmbLenguage, "CmbLenguage");
            this.CmbLenguage.FormattingEnabled = true;
            this.CmbLenguage.Items.AddRange(new object[] {
            resources.GetString("CmbLenguage.Items"),
            resources.GetString("CmbLenguage.Items1"),
            resources.GetString("CmbLenguage.Items2")});
            this.CmbLenguage.Name = "CmbLenguage";
            this.CmbLenguage.SelectedIndexChanged += new System.EventHandler(this.CmbLenguage_SelectedIndexChanged);
            // 
            // Main_Form
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.CmbLenguage);
            this.Controls.Add(this.BtnPause);
            this.Controls.Add(this.BtnStop);
            this.Controls.Add(this.BtnPlay);
            this.Controls.Add(this.ListFiles);
            this.Controls.Add(this.BtnOpenFiles);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Name = "Main_Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.Button BtnOpenFiles;
        private System.Windows.Forms.ListBox ListFiles;
        private System.Windows.Forms.Button BtnPlay;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnPause;
        private System.Windows.Forms.ComboBox CmbLenguage;
    }
}

