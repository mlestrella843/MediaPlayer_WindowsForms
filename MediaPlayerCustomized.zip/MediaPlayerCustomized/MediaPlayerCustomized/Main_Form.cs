﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace MediaPlayerCustomized
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void BtnOpenFiles_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Multiselect = true, ValidateNames = true, Filter = "WMV|*.wmv|WAV|*.wav|MP3|*.mp3|MP4|*.mp4|MKV|*.mkv" } )
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                { 
                    List<MediaFile> files = new List<MediaFile>();
                    foreach (string filename in ofd.FileNames)
                    { 
                        FileInfo fi = new FileInfo(filename);
                        files.Add(new MediaFile() { FileName = Path.GetFileNameWithoutExtension(fi.FullName), Path = fi.FullName });                                   
                    }
                      ListFiles.DataSource = files;
                               
                }
            
            }
        }

        private void ListFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            MediaFile file = ListFiles.SelectedItem as MediaFile;
            if (file != null)
            {
                axWindowsMediaPlayer1.URL = file.Path;
                axWindowsMediaPlayer1.Ctlcontrols.play();
                      
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListFiles.ValueMember = "Path";
            ListFiles.DisplayMember = "FileName";
        }

        private void BtnEnglish_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnFrench_Click(object sender, EventArgs e)
        {

            
        }

        private void CmbLenguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (CmbLenguage.SelectedIndex)
            {
                case 0:
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en");
                    break;
                    
                    case 1:
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("es");
                    break;

                case 2:
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fr");
                    break;

            }
            this.Controls.Clear();
            InitializeComponent();

        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {            
                axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }

        private void BtnPause_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.pause();
        }
    }
}
